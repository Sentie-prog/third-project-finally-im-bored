package ru.samsung.gamestudio.objects;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import ru.samsung.gamestudio.GameSettings;

import java.util.Random;

public class TrashObject extends GameObject {

    private static final int PADDING_HORIZONTAL = 30;
    private static final Random RANDOM = new Random();

    private static final float SPECIAL_TRASH_CHANCE = 0.1f;
    private static final float EXTRA_LIFE_CHANCE = 0.15f;

    private int livesLeft;
    private boolean isSpecial;
    private int initialLives;
    private Texture currentTexture;

    public TrashObject(int width, int height, String texturePath, World world) {
        super(
                texturePath,
                width / 2 + PADDING_HORIZONTAL + RANDOM.nextInt((GameSettings.SCREEN_WIDTH - 2 * PADDING_HORIZONTAL - width)),
                GameSettings.SCREEN_HEIGHT + height / 2,
                width, height,
                GameSettings.TRASH_BIT,
                world
        );

        body.setLinearVelocity(new Vector2(0, -GameSettings.TRASH_VELOCITY));

        currentTexture = new Texture(Gdx.files.internal(texturePath));

        determineTrashType();
        initialLives = livesLeft;
    }

    private void determineTrashType() {
        float randomValue = RANDOM.nextFloat();

        if (randomValue < SPECIAL_TRASH_CHANCE) {
            makeSpecial();
        } else if (randomValue < SPECIAL_TRASH_CHANCE + EXTRA_LIFE_CHANCE) {
            makeDurable();
        } else {
            livesLeft = 1;
            isSpecial = false;
        }
    }

    private void makeSpecial() {
        livesLeft = 3;
        isSpecial = true;
        changeTexture("textures/special_trash.png");
    }

    private void makeDurable() {
        livesLeft = 2;
        isSpecial = false;
        changeTexture("textures/durable_trash.png");
    }

    private void changeTexture(String newTexturePath) {
        if (currentTexture != null) {
            currentTexture.dispose();
        }

        currentTexture = new Texture(Gdx.files.internal(newTexturePath));
    }

    public boolean isAlive() {
        return livesLeft > 0;
    }

    public boolean isInFrame() {
        return getY() + height / 2 > 0;
    }

    @Override
    public void hit() {
        if (livesLeft > 0) {
            livesLeft--;

            if (isSpecial && livesLeft == 1) {
                changeTexture("textures/durable_trash.png");
            } else if (!isSpecial && initialLives > 1 && livesLeft == 1) {
                changeTexture("textures/special_trash.png");
            }
        }
    }

    public boolean isSpecial() {
        return isSpecial;
    }

    public int getLivesLeft() {
        return livesLeft;
    }

    public int getInitialLives() {
        return initialLives;
    }

    @Override
    public void draw(SpriteBatch batch) {
        if (currentTexture != null && isAlive()) {
            batch.draw(
                    currentTexture,
                    getX() - width / 2,
                    getY() - height / 2,
                    width,
                    height
            );
        }
    }

    public void cleanup() {
        if (currentTexture != null) {
            currentTexture.dispose();
            currentTexture = null;
        }
    }
}